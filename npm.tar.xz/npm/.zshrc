PROMPT='%F{cyan}%~%f '

alias rc="nvim ~/.zshrc"
alias ncon="cd ~/.config/nvim/"
alias ycon="cd ~/.config/yazi/"
alias hcon="cd ~/.config/hypr/"
alias kcon="cd ~/.config/kitty/"
alias conf="cd ~/.config/"
alias ww="awww img"
alias prj="cd ~/my_fils/Projects/"
alias arc="cd ~/my_fils/Archives/"
alias scr="cd ~/my_fils/scripts/"
alias basic="cd ~/my_fils/Learning/"
alias loc="cd ~/.local/"

alias rhypr="hyprctl reload"

alias rosepine="awww img ~/wallp/rosepine.png"
alias purple="awww img ~/wallp/purple-arch.png"

alias ..="cd .."
alias ...="cd ../.."
alias ll="ls -lahF"
alias l="ls -lh"

alias gst="get status"
alias ga="get add"
alias gaa="get add --all"
alias gc="get commit -m"
alias gp="get push"
alias gl="get pull"
alias gco="get checkout"
alias gb="get branch"
alias gd="get diff"

alias c="clear"
alias h="history"
alias reload="source ~/.zshrc"

HISTFILE=~/.zsh_history
HISTSIZE=10000
SAVEHIST=10000
setopt HIST_IGNORE_ALL_DUPS

autoload -Uz compinit
zstyle ':completion:*' menu select

export CLICOLOR=1
export LSCOLORS="Gxfxcxdxbxegedabagacad"

export EDITOR="nvim"

export PATH="$HOME/.local/bin:$PATH"
export PATH="$HOME/.local/npm/bin:$PATH"
export PATH="$HOME/Desktop/node/bin:$PATH"

export MYSQL_HOME="$HOME/Desktop/mysql"            
export PATH="$MYSQL_HOME/bin:$PATH"
export LD_LIBRARY_PATH="$MYSQL_HOME/lib:$LD_LIBRARY_PATH"

alias deamonSQL="mysqld --defaults-file=/home/inopi/Desktop/mysql/etc/my.cnf &"
alias startSQL="mysql --defaults-file=~/Desktop/mysql/etc/my.cnf -u root"
